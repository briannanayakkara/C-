﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp6
{

    class bog // laver en klasse 
    {
        public void PrintInfo () //laver en methode 
        {Console.WriteLine("Jeg er bogen");}

    }


}
