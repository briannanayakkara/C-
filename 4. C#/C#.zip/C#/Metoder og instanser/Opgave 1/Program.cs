﻿using System;

namespace ConsoleApp6
{

    class MainClass
    {
        static void Main(string[] args)
        {

            bog SherlockHolmes = new bog(); // laver en objekt for klassen 

            SherlockHolmes.PrintInfo(); // kander den methode jeg har lavet i klassen 

            Console.ReadKey();
            
        }

        
    }
}
