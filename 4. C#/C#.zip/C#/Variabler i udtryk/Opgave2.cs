﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    class Program
    {
        static void Main(string[] args)
        {
            double num1 = 1, num2 = 2, num3 = 3, result;


            result =num1+num2+num3;

          
            Console.WriteLine(result*9);

            Console.ReadKey();

        }
    }
}
