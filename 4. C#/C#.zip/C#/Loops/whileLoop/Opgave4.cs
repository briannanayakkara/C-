﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
  
    class Program
    {
        
       
        static void Main(string[] args)
        

            {
            int i = 20;
            while (i >= 1)
            {
                Console.WriteLine(i);
                i--;
            }

                Console.ReadKey();
            }
        

    }
}
    