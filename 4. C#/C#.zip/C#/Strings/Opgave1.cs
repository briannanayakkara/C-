﻿using System;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            {

                string name = "Brian"; int age = 19; double hight = 176.56;

                Console.WriteLine(name);
                Console.WriteLine(age);
                Console.WriteLine(hight);
                Console.ReadKey();
            }
        }
    }
}