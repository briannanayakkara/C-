﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    class Program
    {
        static void Main(string[] args)
        {
            string name = "Nanayakkara"; int age = 19; double hight = 176.56;

            Console.WriteLine(name);
            Console.WriteLine(age);
            Console.WriteLine(hight);
            Console.ReadKey();
        }
    }
}
