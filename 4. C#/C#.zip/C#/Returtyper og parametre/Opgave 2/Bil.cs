﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program
{
    class Bil // laver en klasse
    {
        public void MoterOn() { Console.WriteLine("Motoren er startet"); } //laver en methode som skriver at motern er startet
        public void MoterOff() { Console.WriteLine("Motoren er slukket"); } //laver en methode som skriver at motern er slukket

        public void FillGas(double liters) { Console.WriteLine("Filled tank with:{0} liters",liters); }
    }
}
