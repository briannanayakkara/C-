﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            int tal1 = 5, tal2 = 3;
            Console.WriteLine(tal1);
            Console.WriteLine(tal2);
            Console.ReadKey();
        }
    }
}
